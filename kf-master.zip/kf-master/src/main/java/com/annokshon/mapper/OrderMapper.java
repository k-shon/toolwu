package com.annokshon.mapper;

public interface OrderMapper {

}
