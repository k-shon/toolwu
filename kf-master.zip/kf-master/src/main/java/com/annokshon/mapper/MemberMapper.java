package com.annokshon.mapper;

public interface MemberMapper {

}
