package com.annokshon.mapper;

public interface ApplyMapper {

}
