package com.annokshon.mapper;

public interface GoodsMapper {

}
