package com.annokshon.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.annokshon.entity.Dojo;

public interface DojoMapper {

	@Insert("INSERT INTO DOJO(name,phone,address,description) VALUES(#{name},#{phone},#{address},#{description})")
	int save(Dojo dojo);
	
	@Select("SELECT * FROM dojo where id=#{dojo_id}")
	List<Dojo> selectByDojoId(int dojo_id);
	
	@Select("SELECT*FROM dojo")
	List<Dojo> selectAll();
}
