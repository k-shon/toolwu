package com.annokshon.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.annokshon.entity.User;

public interface UserMapper {

	@Select("SELECT * FROM user")
	public List<User> getUserList();
}
