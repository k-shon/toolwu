package com.annokshon.mapper;

public interface PersonMapper {

}
