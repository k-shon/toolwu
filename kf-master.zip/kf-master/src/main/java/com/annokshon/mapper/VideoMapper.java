package com.annokshon.mapper;

public interface VideoMapper {

}
