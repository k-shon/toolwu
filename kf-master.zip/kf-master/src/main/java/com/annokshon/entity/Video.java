package com.annokshon.entity;

/*
 * 视频
 */
public class Video {

}
