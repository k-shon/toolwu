package com.annokshon.service.impl;

import com.annokshon.service.StoreService;

public class StoreServiceImpl implements StoreService {

}
