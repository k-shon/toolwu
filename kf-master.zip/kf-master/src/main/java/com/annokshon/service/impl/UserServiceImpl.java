package com.annokshon.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.annokshon.entity.User;
import com.annokshon.mapper.UserMapper;
import com.annokshon.service.UserService;

public class UserServiceImpl implements UserService{

	@Autowired
	private UserMapper userMapper;
	
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return userMapper.getUserList();
	}
	
	public UserMapper getUserMapper() {
		return userMapper;
	}
	public void setUserMapper(UserMapper userMapper) {
		this.userMapper = userMapper;
	}

}
