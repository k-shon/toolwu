package com.annokshon.service;

public interface GoodsService {

}
