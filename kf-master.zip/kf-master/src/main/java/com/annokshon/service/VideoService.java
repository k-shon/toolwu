package com.annokshon.service;

public interface VideoService {

}
