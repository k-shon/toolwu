package com.annokshon.service.impl;

import com.annokshon.service.GoodsService;

public class GoodsServiceImpl implements GoodsService {

}
