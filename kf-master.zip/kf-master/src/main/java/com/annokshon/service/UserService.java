package com.annokshon.service;

import java.util.List;

import com.annokshon.entity.User;

public interface UserService {

	public List<User> getAllUser();
}
