package com.annokshon.service.impl;

import com.annokshon.service.MemberService;

public class MemberServiceImpl implements MemberService{

}
