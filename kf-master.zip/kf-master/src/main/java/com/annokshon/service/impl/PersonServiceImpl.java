package com.annokshon.service.impl;

import com.annokshon.service.PersonService;

public class PersonServiceImpl implements PersonService {

}
