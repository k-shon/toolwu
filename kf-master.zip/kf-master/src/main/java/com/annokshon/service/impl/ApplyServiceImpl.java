package com.annokshon.service.impl;

import com.annokshon.service.ApplyService;

public class ApplyServiceImpl implements ApplyService {

}
