package com.annokshon.service.impl;

import com.annokshon.service.VideoService;

public class VideoServiceImpl implements VideoService {

}
