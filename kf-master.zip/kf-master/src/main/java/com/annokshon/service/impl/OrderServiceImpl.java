package com.annokshon.service.impl;

import com.annokshon.service.OrderService;

public class OrderServiceImpl implements OrderService {

}
