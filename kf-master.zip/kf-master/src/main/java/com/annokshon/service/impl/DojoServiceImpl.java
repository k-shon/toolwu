package com.annokshon.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.annokshon.entity.Dojo;
import com.annokshon.mapper.DojoMapper;
import com.annokshon.service.DojoService;

@Service
public class DojoServiceImpl implements DojoService {

	@Autowired
	private DojoMapper dojoMapper;
	public boolean save(Dojo dojo) {
		// TODO Auto-generated method stub
		int i;
		i = dojoMapper.save(dojo);
		if(i!=0)
			return true;
		return false;
	}
	@Override
	//根据id查询武馆信息
	public List<Dojo> selectByDojoId(int dojo_id) {
		// TODO Auto-generated method stub
		List<Dojo> dojolist = dojoMapper.selectByDojoId(dojo_id);  //调用dao的方法
		return dojolist;
	}
	@Override
	//查询全部武馆信息
	public List<Dojo> selectAll() {
		// TODO Auto-generated method stub
		return dojoMapper.selectAll();
	}
	
}
