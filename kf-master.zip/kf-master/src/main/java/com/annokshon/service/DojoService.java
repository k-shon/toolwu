package com.annokshon.service;

import java.util.List;

import com.annokshon.entity.Dojo;

public interface DojoService {

	boolean save(Dojo dojo);
	//根据id查询武馆信息
	List<Dojo> selectByDojoId(int dojo_id);
	
	//查询全部武馆信息
	List<Dojo> selectAll();
}
