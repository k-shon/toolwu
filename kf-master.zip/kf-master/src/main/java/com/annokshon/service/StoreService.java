package com.annokshon.service;

public interface StoreService {

}
