package com.annokshon.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.annokshon.entity.Dojo;
import com.annokshon.service.DojoService;
import com.annokshon.utils.JSONResult;

@RestController
@RequestMapping("dojo")
public class DojoController {
	@Autowired  //自动注入
	private DojoService dojoServiceimpl;
	
	@RequestMapping(value="/getDojoById",method=RequestMethod.POST)
	public JSONResult getDojoById(int dojo_id) {
		System.out.println("参数dojo_id："+dojo_id);
		List<Dojo> dojoList = dojoServiceimpl.selectByDojoId(dojo_id);
		return JSONResult.ok(dojoList);
	}
	@RequestMapping(value="/post",method=RequestMethod.POST)
	public JSONResult getDojoAll() {
		System.out.println("查询所有dojo");
		List<Dojo> dojoList = dojoServiceimpl.selectAll();
		return JSONResult.ok(dojoList);
	}
}
